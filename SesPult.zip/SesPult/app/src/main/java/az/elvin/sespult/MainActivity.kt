package az.elvin.sespult

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import java.io.File
import java.net.NetworkInterface
import java.util.Locale
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREFS = "sespult"
        private const val K_USAGE = "usage"
        private const val K_DEVICE = "device_key"
        private const val K_LOOP = "loop"
        private const val K_BOOST = "boost_db"
        private const val DEFAULT_USAGE = "ALARM"

        // Safe zone: məzmun ekranın neçə faizini tutsun (qalan hissə kənarlarda boş qalır).
        // Monitorda kənarlar kəsilirsə bu rəqəmləri azaldın, məsələn 0.75f.
        private const val SAFE_W = 0.84f
        private const val SAFE_H = 0.86f
    }

    private lateinit var audio: AudioManager
    private lateinit var prefs: SharedPreferences
    private lateinit var soundsDir: File

    private lateinit var root: View
    private lateinit var nowPlaying: TextView
    private lateinit var stopBtn: MaterialButton
    private lateinit var progress: LinearProgressIndicator
    private lateinit var deviceDropdown: MaterialAutoCompleteTextView
    private lateinit var usageGroup: ChipGroup
    private lateinit var volumeSlider: Slider
    private lateinit var volumeLabel: TextView
    private lateinit var volumeValue: TextView
    private lateinit var boostSlider: Slider
    private lateinit var boostValue: TextView
    private lateinit var loopSwitch: MaterialSwitch
    private lateinit var serverSwitch: MaterialSwitch
    private lateinit var serverUrl: TextView
    private lateinit var pinChip: Chip
    private lateinit var serverStatus: TextView
    private lateinit var soundsTitle: TextView
    private lateinit var emptyText: TextView
    private lateinit var listBox: LinearLayout

    private var devices: List<AudioDeviceInfo> = emptyList()
    private var selectedDevice = 0 // 0 = avtomatik
    private var player: MediaPlayer? = null
    private var enhancer: LoudnessEnhancer? = null
    private var playingFile: File? = null
    private var server: UploadServer? = null
    private val pin = Random.nextInt(1000, 9999).toString()
    private val handler = Handler(Looper.getMainLooper())

    private val usages = linkedMapOf(
        "ALARM" to AudioAttributes.USAGE_ALARM,
        "MEDIA" to AudioAttributes.USAGE_MEDIA,
        "NOTIFICATION" to AudioAttributes.USAGE_NOTIFICATION,
        "NAVIGATION" to AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE,
        "ASSISTANT" to AudioAttributes.USAGE_ASSISTANT,
        "GAME" to AudioAttributes.USAGE_GAME
    )
    private var usageName = DEFAULT_USAGE

    private val progressTick = object : Runnable {
        override fun run() {
            val mp = player ?: return
            try {
                val d = mp.duration
                if (d > 0) progress.setProgressCompat((mp.currentPosition * 1000L / d).toInt(), true)
            } catch (_: Exception) {}
            handler.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        soundsDir = File(filesDir, "sounds").also { it.mkdirs() }
        setContentView(R.layout.activity_main)
        bindViews()
        applySafeZone()
        applyColumns()
        restoreAndWire()
        refreshDevices()
        refreshList()
    }

    override fun onResume() {
        super.onResume()
        updateVolumeSlider()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applySafeZone()
        applyColumns()
    }

    // ---------- UI qurulması ----------

    private fun bindViews() {
        root = findViewById(R.id.root)
        nowPlaying = findViewById(R.id.nowPlaying)
        stopBtn = findViewById(R.id.stopBtn)
        progress = findViewById(R.id.progress)
        deviceDropdown = findViewById(R.id.deviceDropdown)
        usageGroup = findViewById(R.id.usageGroup)
        volumeSlider = findViewById(R.id.volumeSlider)
        volumeLabel = findViewById(R.id.volumeLabel)
        volumeValue = findViewById(R.id.volumeValue)
        boostSlider = findViewById(R.id.boostSlider)
        boostValue = findViewById(R.id.boostValue)
        loopSwitch = findViewById(R.id.loopSwitch)
        serverSwitch = findViewById(R.id.serverSwitch)
        serverUrl = findViewById(R.id.serverUrl)
        pinChip = findViewById(R.id.pinChip)
        serverStatus = findViewById(R.id.serverStatus)
        soundsTitle = findViewById(R.id.soundsTitle)
        emptyText = findViewById(R.id.emptyText)
        listBox = findViewById(R.id.listBox)
    }

    /** Bütün məzmunu ekranın ortasına yığır, kənarlarda boşluq saxlayır. */
    private fun applySafeZone() {
        val dm = resources.displayMetrics
        val landscape = dm.widthPixels > dm.heightPixels
        val fw = if (landscape) SAFE_W else 0.94f
        val fh = if (landscape) SAFE_H else 0.92f
        val lp = root.layoutParams as FrameLayout.LayoutParams
        lp.width = (dm.widthPixels * fw).toInt()
        lp.height = (dm.heightPixels * fh).toInt()
        lp.gravity = Gravity.CENTER
        root.layoutParams = lp
    }

    /** Geniş ekranda (maşın monitoru) iki sütun, dar ekranda bir sütun. */
    private fun applyColumns() {
        val leftCol = findViewById<LinearLayout>(R.id.leftCol)
        val rightCol = findViewById<LinearLayout>(R.id.rightCol)
        val rightScroll = findViewById<ScrollView>(R.id.rightScroll)
        val soundsCard = findViewById<MaterialCardView>(R.id.soundsCard)
        val wide = resources.configuration.screenWidthDp >= 700
        (soundsCard.parent as? LinearLayout)?.removeView(soundsCard)
        if (wide) {
            rightCol.addView(soundsCard)
            rightScroll.visibility = View.VISIBLE
        } else {
            leftCol.addView(soundsCard, 0) // dar ekranda səslər yuxarıda
            rightScroll.visibility = View.GONE
        }
    }

    private fun restoreAndWire() {
        // Səs növü — yadda qalan seçim, ilk dəfə ALARM
        usageName = prefs.getString(K_USAGE, DEFAULT_USAGE)?.takeIf { it in usages } ?: DEFAULT_USAGE
        for (i in 0 until usageGroup.childCount) {
            val c = usageGroup.getChildAt(i) as? Chip ?: continue
            c.isChecked = c.tag == usageName
        }
        usageGroup.setOnCheckedStateChangeListener { group, ids ->
            val chip = ids.firstOrNull()?.let { group.findViewById<Chip>(it) } ?: return@setOnCheckedStateChangeListener
            usageName = chip.tag as String
            prefs.edit().putString(K_USAGE, usageName).apply()
            updateVolumeSlider()
            updateNowPlaying()
        }

        // Loop
        loopSwitch.isChecked = prefs.getBoolean(K_LOOP, false)
        loopSwitch.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean(K_LOOP, on).apply()
            player?.isLooping = on
        }

        // Boost
        val savedBoost = prefs.getInt(K_BOOST, 0).coerceIn(0, 20)
        boostSlider.value = savedBoost.toFloat()
        boostValue.text = boostText(savedBoost)
        boostSlider.setLabelFormatter { boostText(it.toInt()) }
        boostSlider.addOnChangeListener { _, v, _ ->
            val db = v.toInt()
            boostValue.text = boostText(db)
            prefs.edit().putInt(K_BOOST, db).apply()
            player?.let { applyBoost(it) }
        }

        // Sistem səsi
        volumeSlider.setLabelFormatter { it.toInt().toString() }
        volumeSlider.addOnChangeListener { _, v, fromUser ->
            volumeValue.text = "${v.toInt()} / ${volumeSlider.valueTo.toInt()}"
            if (fromUser) {
                try {
                    audio.setStreamVolume(streamFor(usageName), v.toInt(), 0)
                } catch (e: Exception) {
                    toast("Sistem səsini dəyişmək olmadı: ${e.message}")
                }
            }
        }

        // Çıxış
        deviceDropdown.setOnItemClickListener { _, _, pos, _ ->
            selectedDevice = pos
            prefs.edit().putString(K_DEVICE, if (pos == 0) "" else keyOf(devices[pos - 1])).apply()
        }
        findViewById<MaterialButton>(R.id.refreshBtn).setOnClickListener {
            refreshDevices()
            toast("Çıxışlar yeniləndi (${devices.size})")
        }

        stopBtn.setOnClickListener { stopPlayback() }
        serverSwitch.setOnCheckedChangeListener { _, on -> setServer(on) }
        updateNowPlaying()
    }

    private fun boostText(db: Int) = if (db <= 0) "Söndürülüb" else "+$db dB"

    private fun toast(msg: String) {
        Snackbar.make(root, msg, Snackbar.LENGTH_LONG).show()
    }

    // ---------- Səs səviyyəsi ----------

    private fun streamFor(usage: String): Int = when (usage) {
        "ALARM" -> AudioManager.STREAM_ALARM
        "NOTIFICATION" -> AudioManager.STREAM_NOTIFICATION
        else -> AudioManager.STREAM_MUSIC
    }

    private fun updateVolumeSlider() {
        val stream = streamFor(usageName)
        val streamName = when (stream) {
            AudioManager.STREAM_ALARM -> "ALARM"
            AudioManager.STREAM_NOTIFICATION -> "NOTIFICATION"
            else -> "MEDIA"
        }
        volumeLabel.text = "Sistem səsi ($streamName)"
        try {
            val max = audio.getStreamMaxVolume(stream)
            val min = if (Build.VERSION.SDK_INT >= 28) audio.getStreamMinVolume(stream) else 0
            val cur = audio.getStreamVolume(stream)
            if (max <= min) {
                volumeSlider.isEnabled = false
                return
            }
            volumeSlider.isEnabled = true
            volumeSlider.valueFrom = min.toFloat()
            volumeSlider.valueTo = max.toFloat()
            volumeSlider.value = cur.coerceIn(min, max).toFloat()
            volumeValue.text = "$cur / $max"
        } catch (_: Exception) {
            volumeSlider.isEnabled = false
        }
    }

    // ---------- Çıxış cihazları ----------

    private fun typeName(t: Int): String = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "builtin speaker"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "earpiece"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "bluetooth a2dp"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "bluetooth sco"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "wired headphones"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired headset"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "usb device"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "usb headset"
        AudioDeviceInfo.TYPE_LINE_ANALOG -> "line analog"
        AudioDeviceInfo.TYPE_AUX_LINE -> "aux line"
        AudioDeviceInfo.TYPE_BUS -> "bus"
        AudioDeviceInfo.TYPE_TELEPHONY -> "telephony"
        else -> "type $t"
    }

    private fun addrOf(d: AudioDeviceInfo) = if (Build.VERSION.SDK_INT >= 28) d.address ?: "" else ""

    /** Cihazı yenidən başlatmadan sonra da tanımaq üçün açar (id dəyişə bilər). */
    private fun keyOf(d: AudioDeviceInfo) = "${d.type}|${d.productName}|${addrOf(d)}"

    private fun refreshDevices() {
        devices = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val names = mutableListOf("Avtomatik (default)")
        names += devices.map { d ->
            // Maşında AVAS çıxışı varsa, adətən "bus" növündə və ya address-də görünəcək
            val addr = addrOf(d)
            "${d.productName} · ${typeName(d.type)} · id ${d.id}" + (if (addr.isNotEmpty()) " · $addr" else "")
        }
        deviceDropdown.setSimpleItems(names.toTypedArray())

        val savedKey = prefs.getString(K_DEVICE, "") ?: ""
        selectedDevice = if (savedKey.isEmpty()) 0
        else devices.indexOfFirst { keyOf(it) == savedKey }.let { if (it >= 0) it + 1 else 0 }
        deviceDropdown.setText(names[selectedDevice], false)
    }

    // ---------- Səs siyahısı ----------

    private fun sizeText(bytes: Long): String =
        if (bytes >= 1024 * 1024) String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
        else "${(bytes / 1024).coerceAtLeast(1)} KB"

    private fun refreshList() {
        listBox.removeAllViews()
        val files = soundsDir.listFiles()?.filter { it.isFile }?.sortedBy { it.name.lowercase() } ?: emptyList()
        soundsTitle.text = if (files.isEmpty()) "Səslər" else "Səslər (${files.size})"
        emptyText.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE

        val inflater = LayoutInflater.from(this)
        val primary = getColor(R.color.playing_stroke)
        val primaryContainer = getColor(R.color.playing_bg)
        val density = resources.displayMetrics.density

        for (f in files) {
            val item = inflater.inflate(R.layout.item_sound, listBox, false) as MaterialCardView
            val isPlaying = playingFile?.absolutePath == f.absolutePath && player != null
            item.findViewById<TextView>(R.id.name).text = f.name
            item.findViewById<TextView>(R.id.meta).text =
                sizeText(f.length()) + (if (isPlaying) "  ·  oxunur" else "")
            item.findViewById<ImageView>(R.id.icon)
                .setImageResource(if (isPlaying) R.drawable.ic_stop else R.drawable.ic_play)
            if (isPlaying) {
                item.strokeColor = primary
                item.strokeWidth = (2 * density).toInt()
                item.setCardBackgroundColor(primaryContainer)
            }
            item.setOnClickListener { if (isPlaying) stopPlayback() else play(f) }
            item.findViewById<MaterialButton>(R.id.del).setOnClickListener {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Silinsin?")
                    .setMessage(f.name)
                    .setNegativeButton("Ləğv et", null)
                    .setPositiveButton("Sil") { _, _ ->
                        if (playingFile?.absolutePath == f.absolutePath) stopPlayback()
                        f.delete()
                        refreshList()
                    }
                    .show()
            }
            listBox.addView(item)
        }
    }

    // ---------- Oxutma ----------

    private fun play(f: File) {
        stopPlayback(refresh = false)
        var created: MediaPlayer? = null
        try {
            val usage = usages[usageName] ?: AudioAttributes.USAGE_ALARM
            val mp = MediaPlayer()
            created = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            if (selectedDevice > 0 && Build.VERSION.SDK_INT >= 28) {
                val dev = devices.getOrNull(selectedDevice - 1)
                if (dev != null && !mp.setPreferredDevice(dev)) {
                    toast("Bu çıxışa yönləndirmək alınmadı (ok=false)")
                }
            }
            mp.isLooping = loopSwitch.isChecked
            mp.setOnCompletionListener { if (!it.isLooping) stopPlayback() }
            mp.setOnErrorListener { _, what, extra ->
                toast("Oxuma xətası ($what/$extra)")
                stopPlayback()
                true
            }
            mp.prepare()
            player = mp
            playingFile = f
            applyBoost(mp)
            mp.start()
            progress.setProgressCompat(0, false)
            progress.visibility = View.VISIBLE
            handler.removeCallbacks(progressTick)
            handler.post(progressTick)
        } catch (e: Exception) {
            if (player == null) try { created?.release() } catch (_: Exception) {}
            stopPlayback(refresh = false)
            toast("Oxuma xətası: ${e.message}")
        }
        updateNowPlaying()
        refreshList()
    }

    /** LoudnessEnhancer ilə səsi sistemin maksimumundan yuxarı gücləndirir. */
    private fun applyBoost(mp: MediaPlayer) {
        val db = boostSlider.value.toInt()
        try {
            if (db <= 0) {
                enhancer?.setEnabled(false)
                return
            }
            val e = enhancer ?: LoudnessEnhancer(mp.audioSessionId).also { enhancer = it }
            e.setTargetGain(db * 100) // millibel
            e.setEnabled(true)
        } catch (ex: Exception) {
            enhancer = null
            toast("Boost bu cihazda işləmədi: ${ex.message}")
        }
    }

    private fun stopPlayback(refresh: Boolean = true) {
        handler.removeCallbacks(progressTick)
        try { enhancer?.release() } catch (_: Exception) {}
        enhancer = null
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        val wasPlaying = player != null
        player = null
        playingFile = null
        progress.visibility = View.INVISIBLE
        updateNowPlaying()
        if (refresh && wasPlaying) refreshList()
    }

    private fun updateNowPlaying() {
        val f = playingFile
        nowPlaying.text = if (f != null && player != null) "▶ ${f.name}  ·  $usageName" else "Hazırdır  ·  $usageName"
        stopBtn.isEnabled = player != null
    }

    // ---------- Server ----------

    private fun setServer(on: Boolean) {
        if (on) {
            if (server?.running == true) return
            try {
                server = UploadServer(soundsDir, pin) { runOnUiThread { refreshList() } }
                server!!.start(8080)
                serverUrl.text = "http://${localIp()}:8080"
                serverUrl.visibility = View.VISIBLE
                pinChip.text = "PIN: $pin"
                pinChip.visibility = View.VISIBLE
                serverStatus.text = "Telefonda brauzerdə bu ünvanı aç. Telefon və monitor eyni Wi-Fi/hotspot-da olmalıdır."
            } catch (e: Exception) {
                server = null
                serverStatus.text = "Server açılmadı: ${e.message}"
                serverSwitch.isChecked = false
            }
        } else {
            server?.stop()
            server = null
            serverUrl.visibility = View.GONE
            pinChip.visibility = View.GONE
            serverStatus.text = "Server söndürülüb"
        }
    }

    private fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (ni.isLoopback || !ni.isUp) continue
                for (a in ni.inetAddresses) {
                    val h = a.hostAddress ?: continue
                    if (!a.isLoopbackAddress && !h.contains(':')) return h
                }
            }
        } catch (_: Exception) {}
        return "?.?.?.?"
    }

    override fun onDestroy() {
        stopPlayback(refresh = false)
        server?.stop()
        super.onDestroy()
    }
}
