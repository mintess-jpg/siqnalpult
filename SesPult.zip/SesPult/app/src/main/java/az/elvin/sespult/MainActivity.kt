package az.elvin.sespult

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.io.File
import java.net.NetworkInterface
import kotlin.random.Random

class MainActivity : Activity() {

    private lateinit var audio: AudioManager
    private lateinit var soundsDir: File
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var usageSpinner: Spinner
    private lateinit var loopBox: CheckBox

    private var devices: List<AudioDeviceInfo> = emptyList()
    private var player: MediaPlayer? = null
    private var server: UploadServer? = null
    private val pin = Random.nextInt(1000, 9999).toString()

    private val usages = listOf(
        "MEDIA" to AudioAttributes.USAGE_MEDIA,
        "ALARM" to AudioAttributes.USAGE_ALARM,
        "NOTIFICATION" to AudioAttributes.USAGE_NOTIFICATION,
        "NAVIGATION" to AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE,
        "ASSISTANT" to AudioAttributes.USAGE_ASSISTANT,
        "GAME" to AudioAttributes.USAGE_GAME
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        soundsDir = File(filesDir, "sounds").also { it.mkdirs() }
        buildUi()
        refreshDevices()
        refreshList()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val title = TextView(this).apply {
            text = "Səs Pultu"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title)

        root.addView(label("Çıxış (kalonka)"))
        deviceSpinner = Spinner(this)
        root.addView(deviceSpinner)
        val refresh = Button(this).apply {
            text = "Çıxışları yenilə"
            setOnClickListener { refreshDevices() }
        }
        root.addView(refresh)

        root.addView(label("Səs növü (usage)"))
        usageSpinner = Spinner(this)
        usageSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, usages.map { it.first }
        )
        root.addView(usageSpinner)

        loopBox = CheckBox(this).apply { text = "Təkrarla (loop)" }
        root.addView(loopBox)

        val stop = Button(this).apply {
            text = "DAYANDIR"
            setOnClickListener { stopPlayback() }
        }
        root.addView(stop)

        root.addView(label("Telefondan yükləmə"))
        status = TextView(this).apply { text = "Server söndürülüb" }
        root.addView(status)
        val srvBtn = Button(this)
        srvBtn.text = "Serveri aç"
        srvBtn.setOnClickListener {
            if (server?.running == true) {
                server?.stop(); server = null
                status.text = "Server söndürülüb"
                srvBtn.text = "Serveri aç"
            } else {
                try {
                    server = UploadServer(soundsDir, pin) { runOnUiThread { refreshList() } }
                    server!!.start(8080)
                    status.text = "Telefondan aç: http://${localIp()}:8080\nPIN: $pin\n(telefon və monitor eyni Wi-Fi/hotspot-da olmalıdır)"
                    srvBtn.text = "Serveri söndür"
                } catch (e: Exception) {
                    server = null
                    status.text = "Server açılmadı: ${e.message}"
                }
            }
        }
        root.addView(srvBtn)

        root.addView(label("Səslər"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun typeName(t: Int): String = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "builtin speaker"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "earpiece"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "bluetooth a2dp"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "bluetooth sco"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "wired headphones"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired headset"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "usb device"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "usb headset"
        AudioDeviceInfo.TYPE_LINE_ANALOG -> "line analog"
        AudioDeviceInfo.TYPE_AUX_LINE -> "aux line"
        AudioDeviceInfo.TYPE_BUS -> "bus"
        AudioDeviceInfo.TYPE_TELEPHONY -> "telephony"
        else -> "type $t"
    }

    private fun refreshDevices() {
        devices = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val names = mutableListOf("Avtomatik (default)")
        names += devices.map { d ->
            // Maşında AVAS çıxışı varsa, adətən "bus" növündə və ya address-də görünəcək
            val addr = if (Build.VERSION.SDK_INT >= 28) d.address else ""
            "${d.productName} | ${typeName(d.type)} | id ${d.id}" +
                (if (addr.isNotEmpty()) " | $addr" else "")
        }
        deviceSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, names
        )
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val files = soundsDir.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
        if (files.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "Hələ səs yoxdur. Serveri aç və telefondan yüklə." })
            return
        }
        for (f in files) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val play = Button(this).apply {
                text = "▶ ${f.name}"
                isAllCaps = false
                setOnClickListener { play(f) }
            }
            val del = Button(this).apply {
                text = "Sil"
                setOnClickListener { f.delete(); refreshList() }
            }
            row.addView(play, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(del)
            listBox.addView(row)
        }
    }

    private fun play(f: File) {
        stopPlayback()
        try {
            val usage = usages[usageSpinner.selectedItemPosition].second
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            val sel = deviceSpinner.selectedItemPosition
            if (sel > 0 && Build.VERSION.SDK_INT >= 28) {
                val ok = mp.setPreferredDevice(devices[sel - 1])
                if (!ok) status.text = "Bu çıxışa yönləndirmək alınmadı (ok=false)"
            }
            mp.isLooping = loopBox.isChecked
            mp.setOnCompletionListener { if (!it.isLooping) stopPlayback() }
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            status.text = "Oxuma xətası: ${e.message}"
        }
    }

    private fun stopPlayback() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (ni.isLoopback || !ni.isUp) continue
                for (a in ni.inetAddresses) {
                    val h = a.hostAddress ?: continue
                    if (!a.isLoopbackAddress && !h.contains(':')) return h
                }
            }
        } catch (_: Exception) {}
        return "?.?.?.?"
    }

    override fun onDestroy() {
        stopPlayback()
        server?.stop()
        super.onDestroy()
    }
}
